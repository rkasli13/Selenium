package com.selenium.user;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.selenium.usersrole.UsersRoleDB;


@Service
@Transactional
public class UserService implements UserDetailsService {
 
			private final UserDao userDao;
			@SuppressWarnings("unused")
			private final UserMapper userMapper;
 
			@Autowired
			public UserService(UserDao userDao, UserMapper userMapper) {
					this.userDao = userDao;
					this.userMapper = userMapper;
			}
 
					
		 
			public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
  
				
				UserDB userDB=(UserDB) userDao.getUserDetails(username);
				
				List<GrantedAuthority> authorities = buildUserAuthority(userDB.getUsersRole());
				System.out.println("User Role"+(userDB.getUsersRole().toString()));
				return (UserDetails) buildUserforAuthentication(userDB,authorities);
				
				
			}

 
			private User buildUserforAuthentication(UserDB userDB,List<GrantedAuthority> authorities)
			{
				return new User(userDB.getUsername(),userDB.getPassword(),userDB.isEnabled(),true,true,true,authorities);
			}
 
			private List<GrantedAuthority> buildUserAuthority(Set<UsersRoleDB> userRole)
			{
				Set<GrantedAuthority> setAuth = new HashSet<GrantedAuthority>();
  
				for(UsersRoleDB Role : userRole)
				{
					setAuth.add(new SimpleGrantedAuthority(Role.getUserRoleDB().getRole()));
				}
				List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuth);
				return Result;
  
 }



}