package com.selenium.user;

import java.util.HashSet;
import java.util.Set;


import com.selenium.usersrole.UsersRoleDB;

public class UserResource {
	
	private String username;
	private String password;
	private Boolean enabled;
	private Set<UsersRoleDB> usersRole = new HashSet<UsersRoleDB>(0);

	public Boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	
	
	
	
	
	public Set<UsersRoleDB> getUsersRole() {
		return usersRole;
	}
	public void setUsersRole(Set<UsersRoleDB> usersRole) {
		this.usersRole = usersRole;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
