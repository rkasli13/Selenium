package com.selenium.user;

import org.springframework.stereotype.Component;

@Component
public class UserMapper {
	
	public UserResource fromEntity(UserDB user) {
		UserResource userResource;

		userResource = new UserResource();
		userResource.setUsername(user.getUsername());
		userResource.setPassword(user.getPassword());
		userResource.setEnabled(user.isEnabled());
		userResource.setUsersRole(user.getUsersRole());

		return userResource;
	}
	public UserDB fromResource(UserResource userResource) {
		UserDB user;
		
		user = new UserDB();
		user.setUsername(userResource.getUsername());
		user.setPassword(userResource.getPassword());
		user.setEnabled(userResource.isEnabled());
		user.setUsersRole(userResource.getUsersRole());
		return user;
		
	}

}
